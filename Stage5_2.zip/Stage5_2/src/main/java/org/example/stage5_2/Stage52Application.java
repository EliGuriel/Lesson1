package org.example.stage5_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Stage52Application {

    public static void main(String[] args) {
        SpringApplication.run(Stage52Application.class, args);
    }

}
