package org.example.stage5_2.exception;

public class NotExists extends RuntimeException {
    public NotExists(String message) {
        super(message);
    }
}
