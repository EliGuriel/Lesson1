package org.example.stage5_2.exception;

public class StudentIdAndIdMismatch extends RuntimeException{
    public StudentIdAndIdMismatch(String message) {
        super(message);
    }
}

